
function newFunction() {
  document.getElementById("newForm").reset();
}


function newFunction2() {
  document.getElementById("spouse").readOnly = true;

}


function newFunction3() {

  document.getElementById("spouse").readOnly = false;


}




function validateForm() {




  var fname = document.forms["Form"]["firstname"].value;
  var lname = document.forms["Form"]["lastname"].value;
  var Sname = document.forms["Form"]["spouse"].value;


  var pat = /^[A-Z]/;
  var pat2 = /^[a-zA-Z]+$/;


  var Result_F = pat.test(fname);
  var Result_F2 = pat2.test(fname);

  var Result_L = pat2.test(lname);
  var Result_S = pat2.test(Sname);








  var a = document.forms["Form"]["firstname"].value.length;
  var b = document.forms["Form"]["lastname"].value.length;
  var c = document.forms["Form"]["spouse"].value.length;

  if (a == 0) {
    alert("FirstName Field should not be empty");
    firstname.focus();
    return false;



  }

  else if (a > 10) {
    alert("FirstName Field should be LESS THAN 10");
    firstname.focus();
    return false;



  }


  else if (Result_F == false) {
    alert("In FirstName Field First letter always Capital");
    firstname.focus();
    return false;



  }

  else if (Result_F2 == false) {
    alert("In FirstName Field Enter Character Only");
    firstname.focus();
    return false;



  }


  else if (b == 0) {
    alert("LastName Field should not be empty");
    lastname.focus();
    return false;
  }

  else if (b > 10) {
    alert("LastName Field should be LESS THAN 10");
    lastname.focus();
    return false;
  }

  else if (Result_L == false) {
    alert("In LastName Field Enter Character only  ");
    lastname.focus();
    return false;
  }


  else if (document.getElementById("married").checked) {
    if (c == 0) {
      alert("Spouse Field should not be empty");
      spouse.focus();
      return false;
    }

    else if (c > 10) {
      alert("Spouse Field should be LESS THAN 10");
      spouse.focus();
      return false;
    }

    else if (Result_S == false) {
      alert("In Spouse Field Enter Character only  ");
      spouse.focus();
      return false;
    }

  }

  else {

    alert("Thank you, Data Submit");
    return true;

  }



}







